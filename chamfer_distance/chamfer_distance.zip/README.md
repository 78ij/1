Implementation borrowed from https://github.com/chrdiller/pyTorchChamferDistance.
